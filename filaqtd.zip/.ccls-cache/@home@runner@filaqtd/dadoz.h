#define MAX 100
struct num{
  int num;
};
typedef struct fila Fila;

Fila* cria();
void liberar_fila(Fila* fi);
int fila_cheia(Fila* fi);
int fila_vazia(Fila* fi);
int insere(Fila* fi, struct num num);
int remove_fila(Fila* fi);
void imprimir(Fila* fi);
int teste(Fila* fi, Fila *f2);