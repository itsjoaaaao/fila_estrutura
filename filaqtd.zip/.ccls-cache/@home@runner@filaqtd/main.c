#include <stdio.h>
#include <stdlib.h>
#include "dadoz.h"

struct fila{
  struct num dados[MAX];
  int inicio, fim, qtd;
};

int main(void) {

  Fila *fi, *f2;
  struct num num;
  int i;

  fi = cria();
  f2 = cria();

  for(i=0; i<3; i++){
    printf("Digite um valor:\n");
    scanf("%d", &num.num);
    insere(fi,num);
  }

  for(i=0; i<5; i++){
    printf("Digite um valor:\n");
    scanf("%d", &num.num);
    insere(f2,num);
  }

  teste(fi,f2);
  
  return 0;
}

Fila* cria(){
  Fila *fi;
  fi = (Fila*) malloc(sizeof(Fila));
  if(fi!=NULL){
    fi->inicio = 0;
    fi->fim = 0;
    fi->qtd = 0;
  }
  return fi;
}

void liberar_fila(Fila* fi){
  free(fi);
}

int fila_cheia(Fila* fi){
  if(fi == NULL){
    return 0;
  }
  if(fi->qtd == MAX){
    return 1;
  }else{
    return 0;
  }
}

int fila_vazia(Fila* fi){
  if(fi == NULL){
    return 0;
  }
  if(fi->qtd == 0){
    return 1;
  }else{
    return 0;
  }
}

int insere(Fila* fi, struct num num){
  if(fi == NULL) return 0;
  if(fila_cheia(fi)) return 0;
  fi->dados[fi->fim] = num;
  fi->fim = (fi->fim+1)%MAX;
  fi->qtd++;
  return 1;
}

int remove_fila(Fila* fi){
  if(fi == NULL || fila_vazia(fi)) return 0;
  fi->inicio = (fi->inicio+1)%MAX;
  fi->qtd--;
  return 1;
}

void imprimir(Fila* fi){
    if(fi == NULL)
        return;
    int i = fi->inicio-1;
    while(i != fi->fim-1){
        i = (i + 1) % MAX;
        printf("%d ", fi->dados[i].num);
        //printf("-------------------------------\n");
    }
}

int teste(Fila* fi, Fila *f2){
  if(fi == NULL && f2 == NULL){
    return 0;
  }
  if(fi->qtd > f2->qtd){
    printf("a primeira fila é maior\n");
  }else if(f2->qtd > fi->qtd){
    printf("a segunda fila é maior\n");
  } 
}
